import string

# The ciphertext to be decrypted
ciphertext = "FLI FIXREZQRKZFE YRJ ZUVEKZWZVU JVRKKCV, NRJYZEXKFE RJ R GFKVEKZRC KRIXVK WFI FLI LGTFDZEX FGVIRKZFE. NV SVCZVMV KYRK KYZJ CFTRKZFE GIVJVEKJ JVMVIRC FGGFIKLEZKZVJ WFI LJ KF JKIZBV TIZKZTRC ZEWIRJKILTKLIV REU UZJILGK KYV FGVIRKZFEJ FW FLI RUMVIJRIZVJ. FLI FGVIRKZMVJ RIV TLIIVEKCP TFEULTKZEX IVTFEERZJJRETV REU DRBZEX GIVGRIRKZFEJ WFI KYV RKKRTB. NV BEFN KYRK KYV RLKYFIZKZVJ ZE JVRKKCV YRMV JKIFEX TRGRSZCZKZVJ, SLK NV RIV TFEWZUVEK ZE FLI RSZCZKZVJ KF FMVITFDV KYVD. NV NZCC TFEKZELV KF FGVIRKV NZKY UZJTIVKZFE REU NZCC EFK SV UVKVIIVU SP REP FSJKRTCVJ ZE FLI GRKY. YKS{J3RKKCV_0G3IRKZ0E_2023}"

def brute_force(ciphertext):
    for i in range(66):
        # Generate the substitution key for this iteration
        substitution_key = {}
        for j, char in enumerate(string.ascii_uppercase):
            substitution_key[char] = string.ascii_uppercase[(j+i) % 26]
        
        # Use the substitution key to decrypt the ciphertext
        plaintext = ''
        for char in ciphertext:
            if char in substitution_key:
                plaintext += substitution_key[char]
            else:
                plaintext += char

        # Check if the plaintext contains the flag format
        if "HTB{" in plaintext:
            flag = plaintext[plaintext.index("HTB{"):plaintext.index("}")+1]
            print(f"Key: {i}")
            print(f"Plaintext: {plaintext}")
            print(f"Flag: {flag}")
            break
        
brute_force(ciphertext)